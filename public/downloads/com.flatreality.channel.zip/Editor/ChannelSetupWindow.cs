using System.IO;
using UnityEditor;
using UnityEngine;

namespace FlatReality.Channel.Editor
{
    public sealed class ChannelSetupWindow : EditorWindow
    {
        private const string Root = "Assets/Flat Reality SDK/Channel";
        private const string ConfigPath = Root + "/Channel Configuration.asset";
        private const string LearnMore = "https://flatreality.eu/partners/sdk/#anychannel";
        private const string Dashboard = "https://dev.flatreality.eu/";
        private string appId = string.Empty;
        private Vector2 scroll;
        private bool showCloudConnect;

        [MenuItem("Tools/Flat Reality SDK/Channel")]
        public static void Open() { GetWindow<ChannelSetupWindow>("Channel").minSize = new Vector2(520, 440); }

        private ChannelConfiguration FindConfiguration() { return AssetDatabase.LoadAssetAtPath<ChannelConfiguration>(ConfigPath); }
        private void OnGUI()
        {
            scroll = EditorGUILayout.BeginScrollView(scroll);
            GUILayout.Space(14); EditorGUILayout.LabelField("Flat Reality SDK", EditorStyles.boldLabel); EditorGUILayout.LabelField("Channel", new GUIStyle(EditorStyles.largeLabel) { fontSize = 25, fontStyle = FontStyle.Bold }); GUILayout.Space(8);
            var config = FindConfiguration();
            if (config == null) DrawFirstRun(); else if (config.Plan == ChannelPlan.Local) DrawLocal(config); else DrawCloud(config);
            EditorGUILayout.EndScrollView();
        }

        private void DrawFirstRun()
        {
            EditorGUILayout.HelpBox("Create a Channel configuration for this project. You can switch plans later.", MessageType.Info); GUILayout.Space(12);
            DrawPlan("Local (Free)", "Create transmissions as ScriptableObject assets. Content ships inside the build and needs no account or network connection.", () => CreateConfig(ChannelPlan.Local, string.Empty));
            GUILayout.Space(10);
            DrawPlan("Cloud", "Connect an AnyChannel App ID. Cloud content can change without rebuilding the game and requires an external AnyChannel account.", () => showCloudConnect = true);
            if (showCloudConnect) { GUILayout.Space(12); DrawCloudConnect(); }
            if (GUILayout.Button("Learn more", GUILayout.Height(30))) Application.OpenURL(LearnMore);
        }

        private void DrawPlan(string title, string description, System.Action action)
        {
            EditorGUILayout.BeginVertical(EditorStyles.helpBox); EditorGUILayout.LabelField(title, new GUIStyle(EditorStyles.boldLabel) { fontSize = 18 }); EditorGUILayout.LabelField(description, EditorStyles.wordWrappedLabel); GUILayout.Space(8); if (GUILayout.Button("Choose " + title, GUILayout.Height(38))) action(); EditorGUILayout.EndVertical();
        }

        private void DrawLocal(ChannelConfiguration config)
        {
            EditorGUILayout.LabelField("Current plan: Local (Free)", new GUIStyle(EditorStyles.boldLabel) { fontSize = 17 });
            EditorGUILayout.HelpBox("Local transmissions remain in your project and are included in the build.", MessageType.Info); GUILayout.Space(12);
            EditorGUILayout.LabelField("Create a transmission", EditorStyles.boldLabel);
            EditorGUILayout.LabelField("1. Click New Transmission.\n2. Fill in Title, Date, Cover and Story Text in the Inspector.\n3. Add the asset to Local Transmissions on the Channel Configuration.\n4. UI integration will be added in the next package milestone.", EditorStyles.wordWrappedLabel); GUILayout.Space(10);
            if (GUILayout.Button("New Transmission", GUILayout.Height(36))) CreateTransmission();
            GUILayout.Space(24); EditorGUILayout.LabelField("Cloud", EditorStyles.boldLabel);
            if (showCloudConnect) DrawCloudConnect();
            else if (GUILayout.Button("Switch to Cloud", GUILayout.Height(34)) && EditorUtility.DisplayDialog("Switch to Cloud?", "Local transmissions will be hidden while Cloud is active. They are not deleted and can only be migrated manually.", "Switch", "Cancel")) { appId = string.Empty; showCloudConnect = true; Repaint(); }
        }

        private void DrawCloud(ChannelConfiguration config)
        {
            EditorGUILayout.LabelField("Current plan: Cloud", new GUIStyle(EditorStyles.boldLabel) { fontSize = 17 }); GUILayout.Space(8);
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            EditorGUILayout.LabelField(string.IsNullOrEmpty(config.AppName) ? "Connected app" : config.AppName, EditorStyles.boldLabel);
            EditorGUILayout.LabelField("App ID", EditorStyles.miniBoldLabel); EditorGUILayout.SelectableLabel(config.AppId, EditorStyles.textField, GUILayout.Height(20));
            EditorGUILayout.LabelField("Subscription", EditorStyles.miniBoldLabel); EditorGUILayout.LabelField(string.IsNullOrEmpty(config.SubscriptionExpiresAt) ? "Not synced yet" : "Active until " + config.SubscriptionExpiresAt);
            EditorGUILayout.EndVertical(); GUILayout.Space(12);
            if (GUILayout.Button("Open Flat Reality SDK Dashboard", GUILayout.Height(34))) Application.OpenURL(Dashboard);
            EditorGUILayout.HelpBox("Create or find an app under AnyChannel → My apps, then copy its App ID. The classic GitHub Pages URL remains a supported fallback during the domain transition.", MessageType.Info);
        }

        private void DrawCloudConnect()
        {
            appId = EditorGUILayout.TextField("App ID", appId);
            if (GUILayout.Button("Connect Cloud", GUILayout.Height(36)))
            {
                if (!System.Text.RegularExpressions.Regex.IsMatch(appId ?? string.Empty, "^app_[a-f0-9]{32}$")) { EditorUtility.DisplayDialog("Invalid App ID", "Copy the complete App ID from AnyChannel → My apps.", "OK"); return; }
                var config = FindConfiguration();
                if (config == null) CreateConfig(ChannelPlan.Cloud, appId);
                else { Undo.RecordObject(config, "Switch Channel to Cloud"); config.ConfigureCloud(appId); EditorUtility.SetDirty(config); AssetDatabase.SaveAssets(); showCloudConnect = false; Repaint(); }
            }
            EditorGUILayout.HelpBox("In the dashboard, open AnyChannel → My apps → Create new app. Copy the generated App ID and paste it here.", MessageType.None);
        }

        private void CreateConfig(ChannelPlan plan, string id)
        {
            Directory.CreateDirectory(Root); var config = CreateInstance<ChannelConfiguration>(); if (plan == ChannelPlan.Cloud) config.ConfigureCloud(id); else config.ConfigureLocal(); AssetDatabase.CreateAsset(config, ConfigPath); AssetDatabase.SaveAssets(); Selection.activeObject = config; Repaint();
        }

        private void CreateTransmission()
        {
            Directory.CreateDirectory(Root + "/Transmissions"); var path = AssetDatabase.GenerateUniqueAssetPath(Root + "/Transmissions/New Transmission.asset"); var asset = CreateInstance<TransmissionAsset>(); AssetDatabase.CreateAsset(asset, path); AssetDatabase.SaveAssets(); Selection.activeObject = asset; EditorGUIUtility.PingObject(asset);
        }
    }
}
