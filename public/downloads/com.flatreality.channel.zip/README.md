# Flat Reality SDK — Channel

Technical alpha for Unity 2022.3 LTS and Unity 6. Open **Tools → Flat Reality SDK → Channel** to create a Local or Cloud configuration.

- Local is fully free, works offline, and stores transmissions as ScriptableObject assets.
- Cloud asks for the public App ID created in Flat Reality SDK Dashboard. It never stores account credentials or secret keys.
- Runtime UI is deliberately not included in this milestone.

Dashboard primary URL: <https://dev.flatreality.eu/>  
Temporary fallback: <https://flat-reality.github.io/FRSDK_Webapp/>

The package first tries the primary delivery path and then the GitHub Pages-compatible fallback. The public snapshot contract is not live yet, so Cloud metadata remains “Not synced yet” until the delivery API milestone.
