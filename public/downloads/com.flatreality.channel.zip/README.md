# Flat Reality SDK — Channel

Technical alpha for Unity 2022.3 LTS and Unity 6. Open **Tools → Flat Reality SDK → Channel** to create a Local or Cloud configuration.

- Local is fully free, works offline, and stores transmissions as ScriptableObject assets.
- Cloud asks for the public App ID created in Flat Reality SDK Dashboard. It never stores account credentials or secret keys.
- Runtime UI is deliberately not included in this milestone.

Dashboard primary URL: <https://dev.flatreality.eu/>  
Temporary fallback: <https://flat-reality.github.io/FRSDK_Webapp/>

Dashboard links support both domains. Runtime delivery uses the domain-independent Supabase Cluster 2 Edge endpoint, so switching the dashboard domain does not require rebuilding games.

`ChannelClient.Load(...)` returns the same `Transmission` runtime model for Local and Cloud. Cloud reads only published/due scheduled transmissions assigned to the configured App ID, keeps a last-known-good JSON cache under `persistentDataPath`, and never stores account credentials or Supabase keys.
