using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.Networking;

namespace FlatReality.Channel
{
    public interface IChannelSource
    {
        void Load(Action<IReadOnlyList<Transmission>> onSuccess, Action<string> onError);
    }

    public sealed class LocalChannelSource : IChannelSource
    {
        private readonly ChannelConfiguration configuration;
        public LocalChannelSource(ChannelConfiguration configuration) { this.configuration = configuration; }
        public void Load(Action<IReadOnlyList<Transmission>> onSuccess, Action<string> onError)
        {
            var result = new List<Transmission>();
            foreach (var asset in configuration.LocalTransmissions) if (asset != null) result.Add(asset.ToTransmission());
            onSuccess?.Invoke(result);
        }
    }

    public sealed class ChannelClient : MonoBehaviour, IChannelSource
    {
        public const string DashboardPrimary = "https://dev.flatreality.eu/";
        public const string DashboardFallback = "https://flat-reality.github.io/FRSDK_Webapp/";
        public const string DeliveryRoot = "https://ecuslqjmsapmswaklpqa.supabase.co/functions/v1/anychannel-delivery/v1/apps/";

        [SerializeField] private ChannelConfiguration configuration;
        public ChannelConfiguration Configuration => configuration;

        public static string GetManifestUrl(string appId)
        {
            return DeliveryRoot + UnityWebRequest.EscapeURL(appId ?? string.Empty) + "/manifest.json";
        }

        public void Load(Action<IReadOnlyList<Transmission>> onSuccess, Action<string> onError)
        {
            if (configuration == null) { onError?.Invoke("Channel Configuration is not assigned."); return; }
            if (configuration.Plan == ChannelPlan.Local)
            {
                new LocalChannelSource(configuration).Load(onSuccess, onError);
                return;
            }
            StartCoroutine(LoadCloud(onSuccess, onError));
        }

        public void LoadManifest(Action<string> onSuccess, Action<string> onError)
        {
            if (configuration == null) { onError?.Invoke("Channel Configuration is not assigned."); return; }
            if (configuration.Plan != ChannelPlan.Cloud) { onError?.Invoke("The current Channel plan is Local."); return; }
            StartCoroutine(DownloadManifest(configuration.AppId, onSuccess, onError));
        }

        private IEnumerator LoadCloud(Action<IReadOnlyList<Transmission>> onSuccess, Action<string> onError)
        {
            string json = null;
            string failure = null;
            yield return DownloadManifest(configuration.AppId, value => json = value, error => failure = error);
            if (string.IsNullOrEmpty(json))
            {
                json = ReadCache(configuration.AppId);
                if (string.IsNullOrEmpty(json)) { onError?.Invoke(failure ?? "AnyChannel Cloud is unavailable and no cached feed exists."); yield break; }
            }

            CloudManifest manifest;
            try { manifest = JsonUtility.FromJson<CloudManifest>(json); }
            catch (Exception exception) { onError?.Invoke("AnyChannel returned invalid JSON: " + exception.Message); yield break; }
            if (manifest == null || manifest.schema_version != "1.0") { onError?.Invoke("Unsupported AnyChannel schema version."); yield break; }

            var transmissions = new List<Transmission>();
            foreach (var item in manifest.transmissions ?? Array.Empty<CloudTransmission>())
            {
                DateTimeOffset parsed;
                DateTimeOffset? date = DateTimeOffset.TryParse(item.published_at, out parsed) ? parsed : (DateTimeOffset?)null;
                transmissions.Add(new Transmission(item.api_key, item.title, item.story_text, date, null, item.cover_url));
            }
            onSuccess?.Invoke(transmissions);
        }

        private IEnumerator DownloadManifest(string appId, Action<string> onSuccess, Action<string> onError)
        {
            using (var request = UnityWebRequest.Get(GetManifestUrl(appId)))
            {
                request.timeout = 10;
                yield return request.SendWebRequest();
                if (request.result == UnityWebRequest.Result.Success)
                {
                    WriteCache(appId, request.downloadHandler.text);
                    onSuccess?.Invoke(request.downloadHandler.text);
                }
                else onError?.Invoke("AnyChannel request failed (" + request.responseCode + "). Last-known-good cache will be used when available.");
            }
        }

        private static string CachePath(string appId)
        {
            return Path.Combine(Application.persistentDataPath, "FlatRealitySDK", "Channel", (appId ?? "unknown") + ".json");
        }

        private static void WriteCache(string appId, string json)
        {
            try { var path = CachePath(appId); Directory.CreateDirectory(Path.GetDirectoryName(path)); File.WriteAllText(path, json); }
            catch (Exception exception) { Debug.LogWarning("AnyChannel cache could not be written: " + exception.Message); }
        }

        private static string ReadCache(string appId)
        {
            try { var path = CachePath(appId); return File.Exists(path) ? File.ReadAllText(path) : null; }
            catch (Exception exception) { Debug.LogWarning("AnyChannel cache could not be read: " + exception.Message); return null; }
        }
    }
}
