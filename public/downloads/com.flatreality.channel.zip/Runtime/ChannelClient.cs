using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

namespace FlatReality.Channel
{
    public interface IChannelSource
    {
        void Load(Action<IReadOnlyList<Transmission>> onSuccess, Action<string> onError);
    }

    public sealed class LocalChannelSource : IChannelSource
    {
        private readonly ChannelConfiguration configuration;
        public LocalChannelSource(ChannelConfiguration configuration) { this.configuration = configuration; }
        public void Load(Action<IReadOnlyList<Transmission>> onSuccess, Action<string> onError)
        {
            var result = new List<Transmission>();
            foreach (var asset in configuration.LocalTransmissions) if (asset != null) result.Add(asset.ToTransmission());
            onSuccess?.Invoke(result);
        }
    }

    public sealed class ChannelClient : MonoBehaviour
    {
        public const string DashboardPrimary = "https://dev.flatreality.eu/";
        public const string DashboardFallback = "https://flat-reality.github.io/FRSDK_Webapp/";
        private static readonly string[] DeliveryRoots =
        {
            "https://dev.flatreality.eu/api/v1/apps/",
            "https://flat-reality.github.io/FRSDK_Webapp/api/v1/apps/"
        };

        [SerializeField] private ChannelConfiguration configuration;
        public ChannelConfiguration Configuration => configuration;

        public void LoadManifest(Action<string> onSuccess, Action<string> onError)
        {
            if (configuration == null) { onError?.Invoke("Channel Configuration is not assigned."); return; }
            if (configuration.Plan != ChannelPlan.Cloud) { onError?.Invoke("The current Channel plan is Local."); return; }
            StartCoroutine(LoadWithFallback(configuration.AppId, 0, onSuccess, onError));
        }

        private IEnumerator LoadWithFallback(string appId, int index, Action<string> onSuccess, Action<string> onError)
        {
            if (index >= DeliveryRoots.Length) { onError?.Invoke("AnyChannel Cloud is currently unavailable. Local content remains untouched."); yield break; }
            var url = DeliveryRoots[index] + UnityWebRequest.EscapeURL(appId) + "/manifest.json";
            using (var request = UnityWebRequest.Get(url))
            {
                request.timeout = 10;
                yield return request.SendWebRequest();
                if (request.result == UnityWebRequest.Result.Success) onSuccess?.Invoke(request.downloadHandler.text);
                else yield return LoadWithFallback(appId, index + 1, onSuccess, onError);
            }
        }
    }
}
