using System;
using System.Collections.Generic;
using UnityEngine;

namespace FlatReality.Channel
{
    public enum ChannelPlan { Local, Cloud }

    [CreateAssetMenu(fileName = "Channel Configuration", menuName = "Flat Reality SDK/Channel Configuration")]
    public sealed class ChannelConfiguration : ScriptableObject
    {
        [SerializeField] private ChannelPlan plan = ChannelPlan.Local;
        [SerializeField] private string appId = string.Empty;
        [SerializeField] private string appName = string.Empty;
        [SerializeField] private Texture2D appIcon;
        [SerializeField] private string subscriptionExpiresAt = string.Empty;
        [SerializeField] private string locale = "en";
        [SerializeField] private List<TransmissionAsset> localTransmissions = new List<TransmissionAsset>();

        public ChannelPlan Plan => plan;
        public string AppId => appId;
        public string AppName => appName;
        public Texture2D AppIcon => appIcon;
        public string SubscriptionExpiresAt => subscriptionExpiresAt;
        public string Locale => string.IsNullOrWhiteSpace(locale) ? "en" : locale;
        public IReadOnlyList<TransmissionAsset> LocalTransmissions => localTransmissions;

#if UNITY_EDITOR
        public void ConfigureLocal() { plan = ChannelPlan.Local; appId = string.Empty; }
        public void ConfigureCloud(string value) { plan = ChannelPlan.Cloud; appId = value == null ? string.Empty : value.Trim(); }
        public void SetCloudMetadata(string name, Texture2D icon, string expiresAt) { appName = name; appIcon = icon; subscriptionExpiresAt = expiresAt; }
#endif
    }
}
