using System;
using UnityEngine;

namespace FlatReality.Channel
{
    [CreateAssetMenu(fileName = "New Transmission", menuName = "Flat Reality SDK/New Transmission")]
    public sealed class TransmissionAsset : ScriptableObject
    {
        [SerializeField] private string apiKey = "my_article_01";
        [SerializeField] private string title = "New transmission";
        [SerializeField] private string date = "";
        [SerializeField] private Texture2D cover;
        [SerializeField, TextArea(8, 30)] private string storyText = "Write your story here.";

        public string ApiKey => apiKey;
        public string Title => title;
        public string Date => date;
        public Texture2D Cover => cover;
        public string StoryText => storyText;

        public Transmission ToTransmission()
        {
            DateTimeOffset parsed;
            DateTimeOffset? timestamp = DateTimeOffset.TryParse(date, out parsed) ? parsed : (DateTimeOffset?)null;
            return new Transmission(apiKey, title, storyText, timestamp, cover);
        }
    }
}
