using System;
using UnityEngine;

namespace FlatReality.Channel
{
    public sealed class Transmission
    {
        public string ApiKey { get; }
        public string Title { get; }
        public string StoryText { get; }
        public DateTimeOffset? Date { get; }
        public Texture2D Cover { get; }

        public Transmission(string apiKey, string title, string storyText, DateTimeOffset? date, Texture2D cover = null)
        {
            ApiKey = apiKey ?? string.Empty;
            Title = title ?? string.Empty;
            StoryText = storyText ?? string.Empty;
            Date = date;
            Cover = cover;
        }
    }

    [Serializable]
    internal sealed class CloudManifest
    {
        public string schema_version;
        public string revision;
        public string app_id;
        public string name;
        public string subscription_expires_at;
        public string feed_url;
    }
}
