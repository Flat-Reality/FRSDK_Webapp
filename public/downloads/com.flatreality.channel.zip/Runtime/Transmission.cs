using System;
using UnityEngine;

namespace FlatReality.Channel
{
    public sealed class Transmission
    {
        public string ApiKey { get; }
        public string Title { get; }
        public string StoryText { get; }
        public DateTimeOffset? Date { get; }
        public Texture2D Cover { get; }
        public string CoverUrl { get; }

        public Transmission(string apiKey, string title, string storyText, DateTimeOffset? date, Texture2D cover = null, string coverUrl = "")
        {
            ApiKey = apiKey ?? string.Empty;
            Title = title ?? string.Empty;
            StoryText = storyText ?? string.Empty;
            Date = date;
            Cover = cover;
            CoverUrl = coverUrl ?? string.Empty;
        }
    }

    [Serializable]
    public sealed class CloudManifest
    {
        public string schema_version;
        public string revision;
        public string app_id;
        public string name;
        public string subscription_expires_at;
        public string app_type;
        public string icon_url;
        public string generated_at;
        public CloudTransmission[] transmissions;
    }

    [Serializable]
    public sealed class CloudTransmission
    {
        public string api_key;
        public string title;
        public string story_text;
        public string cover_url;
        public string published_at;
    }
}
