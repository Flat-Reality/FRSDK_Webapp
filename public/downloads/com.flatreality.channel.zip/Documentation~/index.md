# Channel setup

Open **Tools → Flat Reality SDK → Channel**.

## Local (Free)

Choose Local, click **New Transmission**, then edit Title, Date, Cover and Story Text in the Inspector. Add created assets to the Local Transmissions list on the generated Channel Configuration asset.

## Cloud

Create an app in **Flat Reality SDK Dashboard → AnyChannel → My apps**, copy its App ID, choose Cloud in Unity and paste the value. Switching to Cloud hides Local transmissions but does not delete them. Migration is manual in this alpha.
